package hu.autsoft.demo.useful;

import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class WeatherService {

    private static Map<String, WeatherReport> reports = initMap();

    private static Map<String, WeatherReport> initMap() {
        Map<String, WeatherReport> reports = new HashMap<>();
        reports.put("BUD", new WeatherReport("BUD", 35, "Sunny and really hot."));
        reports.put("NYC", new WeatherReport("NYC", 5, "Raining, not so great."));
        reports.put("BCN", new WeatherReport("BCN", 25, "Cloudy but pleasant."));
        return reports;
    }


    public WeatherReport getWeather(String code){
        if(code.equals("NYC")){
            try {
                Thread.sleep(7000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        return reports.get(code);
    }

}
