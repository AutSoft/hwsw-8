package hu.autsoft.demo.useful;

public class WeatherReport {

    public WeatherReport() {
    }

    public WeatherReport(String code, int temperature, String description) {
        this.code = code;
        this.temperature = temperature;
        this.description = description;
    }

    private String code;

    private int temperature;

    private String description;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getTemperature() {
        return temperature;
    }

    public void setTemperature(int temperature) {
        this.temperature = temperature;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
