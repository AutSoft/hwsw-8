package hu.autsoft.demo.useful;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsefulApplication {

    public static void main(String[] args) {
        SpringApplication.run(UsefulApplication.class, args);
    }

}
