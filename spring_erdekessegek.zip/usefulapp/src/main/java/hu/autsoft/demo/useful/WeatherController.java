package hu.autsoft.demo.useful;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WeatherController {

    private WeatherService weatherService;

    public WeatherController(WeatherService weatherService) {
        this.weatherService = weatherService;
    }

    @GetMapping("/{code}")
    public ResponseEntity<WeatherReport> getReport(@PathVariable("code") String code){
        WeatherReport report = this.weatherService.getWeather(code);
        if(report == null){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(report);
    }


}
